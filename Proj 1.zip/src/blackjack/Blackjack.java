package blackjack;

import java.util.*;

/*
 * Marvin Xu 
 * This program is for the game of blackjack.
 */
public class Blackjack implements BlackjackEngine {

	/**
	 * Constructor you must provide. Initializes the player's account to 200 and the
	 * initial bet to 5. Feel free to initialize any other fields. Keep in mind that
	 * the constructor does not define the deck(s) of cards.
	 * 
	 * @param randomGenerator
	 * @param numberOfDecks
	 */

	private static int total;
	private static int bet;
	private static ArrayList<Card> player;
	private static ArrayList<Card> dealer;
	private static ArrayList<Card> deck;
	private static int deckNum;
	private static Random rand;
	private static int status;

	public Blackjack(Random randomGenerator, int numberOfDecks) {

		total = 200;
		bet = 5;
		deckNum = numberOfDecks;
		player = new ArrayList<Card>();
		dealer = new ArrayList<Card>();
		rand = randomGenerator;

	}

	public int getNumberOfDecks() {

		return deckNum;
	}

	public void createAndShuffleGameDeck() {

		deck = new ArrayList<Card>();
		CardSuit[] suit = CardSuit.values();
		CardValue[] value = CardValue.values();
		player.clear();
		dealer.clear();

		for (int decks = 0; decks < deckNum; decks++) {
			for (CardSuit s : suit) {
				for (CardValue v : value) {

					deck.add(new Card(v, s));
				}
			}
		}

		Collections.shuffle(deck, rand);
	}

	public Card[] getGameDeck() {

		return getCards(deck);
	}

	public void deal() {

		createAndShuffleGameDeck();

		player.add(deck.remove(0));
		dealer.add(deck.remove(0));
		dealer.get(0).setFaceDown();
		player.add(deck.remove(0));
		dealer.add(deck.remove(0));

		total -= bet;

		status = GAME_IN_PROGRESS;

	}

	public Card[] getDealerCards() {

		return getCards(dealer);
	}

	public int[] getDealerCardsTotal() {

		return getTotal(dealer);
	}

	public int getDealerCardsEvaluation() {

		return getEvaluation(dealer);
	}

	public Card[] getPlayerCards() {

		return getCards(player);
	}

	public int[] getPlayerCardsTotal() {

		return getTotal(player);
	}

	public int getPlayerCardsEvaluation() {

		return getEvaluation(player);
	}

	public void playerHit() {

		player.add(deck.remove(0));

		int result = getEvaluation(player);

		if (result == BUST) {

			status = DEALER_WON;

		} else {

			status = GAME_IN_PROGRESS;
		}
	}

	public void playerStand() {

		dealer.get(0).setFaceUp();

		int[] dealerTot = getTotal(dealer);
		int[] playerTot = getTotal(player);

		if (dealerTot != null && dealerTot[dealerTot.length - 1] <= playerTot[playerTot.length - 1]) {
			while (dealerTot != null && dealerTot[dealerTot.length - 1] < 16) {

				dealer.add(deck.remove(0));

				dealerTot = getTotal(dealer);
			}

			// checks to see if dealer busted &compares player vs dealer to see who won &
			// updates the total.
		}

		if (dealerTot == null) {

			status = PLAYER_WON;

			updateTotal();
			return;
		}

		else if (dealerTot[dealerTot.length - 1] < playerTot[playerTot.length - 1]) {

			status = PLAYER_WON;
		} else if (dealerTot[dealerTot.length - 1] > playerTot[playerTot.length - 1]) {

			status = DEALER_WON;
		} else {

			status = DRAW;
		}

		updateTotal();
	}

	public int getGameStatus() {

		return status;
	}

	public void setBetAmount(int amount) {

		bet = amount;
	}

	public int getBetAmount() {

		return bet;
	}

	public void setAccountAmount(int amount) {

		total = amount;
	}

	public int getAccountAmount() {

		return total;
	}

	/* Feel Free to add any private methods you might need */

	/*
	 * getCards returns an array of Cards for a certain hand. Converts arraylist of
	 * cards to array of cards.
	 */
	private Card[] getCards(ArrayList<Card> hand) {

		Card[] toReturn = new Card[hand.size()];

		for (int i = 0; i < hand.size(); i++) {

			toReturn[i] = hand.get(i);
		}

		return toReturn;
	}

	/*
	 * Gives evaluation based on a hand given to it. Returns either HAS_21,
	 * BLACKJACK, BUST, or LESS_THAN_21
	 * 
	 */
	private int getEvaluation(ArrayList<Card> hand) {

		if (getTotal(hand) == null) {

			return BUST;
		} else {

			int[] evaluation = getTotal(hand);

			if (evaluation.length == 2) {
				if (evaluation[1] == 21 && hand.size() == 2) {

					return BLACKJACK;

				} else if ((evaluation[0] == 21 && hand.size() != 2) || evaluation[1] == 21) {

					return HAS_21;

				} else {

					return LESS_THAN_21;
				}
			}

			else if (evaluation[0] == 21) {

				return HAS_21;
			} else {

				return LESS_THAN_21;
			}
		}

	}

	// returns array of the values <21 a possible hand can have
	private int[] getTotal(ArrayList<Card> hand) {

		ArrayList<Integer> total = new ArrayList<Integer>();
		total.add(0);

		for (int i = 0; i < hand.size(); i++) {

			if (hand.get(i).getValue().equals(CardValue.Ace)) {

				total.set(0, total.get(0) + 1);

				if (total.size() == 1) {

					total.add(total.get(0) + 10);
				} else {

					total.set(1, total.get(0) + 10);
				}
			} else {

				for (int q = 0; q < total.size(); q++) {

					total.set(q, total.get(q) + hand.get(i).getValue().getIntValue());
				}
			}

		}

		if (total.size() == 2) {
			if (total.get(1) > 21) {

				total.remove(1);
			}
		}
		if (total.size() == 1) {
			if (total.get(0) > 21) {

				total.remove(0);
			}
		}

		if (total.size() == 0) {

			return null;
		}

		int[] toReturn = new int[total.size()];
		for (int i = 0; i < total.size(); i++) {

			toReturn[i] = total.get(i).intValue();
		}

		return toReturn;
	}

	// updates the total based on the bet and status
	private void updateTotal() {

		if (status != DEALER_WON) {
			if (status == PLAYER_WON) {

				total += bet * 2;
			} else {

				total += bet;
			}
		}
	}
}