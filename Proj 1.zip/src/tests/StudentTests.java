package tests;
import static org.junit.Assert.*;

import java.util.Random;

import org.junit.Test;

import blackjack.Blackjack;
import blackjack.Card;


/**
 * Please put your own test cases into this file, so they can be tested
 * on the server.
*/

public class StudentTests {
	
	@Test
	public void test1DeckCreation() {
		Blackjack blackjack = setBlackJack();

    	String results = SupportPublicTests.pubTest1DeckCreation();
    	System.out.println(results);
    	//assertTrue(SupportPublicTests.correctResults("pubTest1DeckCreation.txt", results));
    	
    	blackjack.deal();
		 results += getCardsString(blackjack.getPlayerCards()) + "\n";
		results += getCardsString(blackjack.getDealerCards()) + "\n";
		results += "*** Stand ***\n";
		blackjack.playerStand();
		results += "Player's Cards: " + "\n";
		results += getCardsString(blackjack.getPlayerCards());
		
		results += "Dealer's Cards: " + "\n";
		results += getCardsString(blackjack.getDealerCards());
		
		String playerEvaluation = mapIntString(blackjack.getPlayerCardsEvaluation());
		String dealerEvaluation = mapIntString(blackjack.getDealerCardsEvaluation());
		results += "Player: " + playerEvaluation + "\n";
		results += "Dealer: " + dealerEvaluation + "\n";
		
		//System.out.println(dealerEvaluation);
		int[] playerValues =  blackjack.getPlayerCardsTotal();
		int[] dealerValues =  blackjack.getDealerCardsTotal();
		
		results += "Player's total(s): ";
		for (int i=0; i<playerValues.length; i++)
			results += playerValues[i] + "\n";
		
		results += "Dealer's total(s): ";
		for (int i=0; i<dealerValues.length; i++) 
			results += dealerValues[i] + "\n";
		
		results += "Game Status: ";
		results += mapIntString(blackjack.getGameStatus());
		
    	System.out.println(results);

    }
	
	public static String pubTest1DeckCreation() {
		Blackjack blackjack = setBlackJack();
		blackjack.createAndShuffleGameDeck();
		
		
		Card[] deck = blackjack.getGameDeck();
		
	
		
		return (getCardsString(deck));
	} 
	private static Blackjack setBlackJack() {
		Random randomGenerator = new Random(1234567L);
		int numberOfDecks = 1;
		Blackjack blackjack = new Blackjack(randomGenerator, numberOfDecks);
	    return blackjack;
	}
	
	private static String getCardsString(Card[] array) {
		String result = "";
		for (int i=0; i<array.length; i++) {
			result += array[i] + "\n";
		}
		return result;
	}
	
	private static String mapIntString(int value) {
		String result;
		switch (value) {
			case Blackjack.DRAW:
				result = "DRAW";
				break;
			case Blackjack.LESS_THAN_21:
				result = "LESS_THAN_21";
				break;
			case Blackjack.BUST:
				result = "BUST";
				break;
			case Blackjack.BLACKJACK:
				result = "BLACKJACK";
				break;
			case Blackjack.HAS_21:
				result = "HAS_21";
				break;
			case Blackjack.DEALER_WON:
				result = "DEALER_WON";
				break;
			case Blackjack.PLAYER_WON:
				result = "PLAYER_WON";
				break;
			case Blackjack.GAME_IN_PROGRESS:
				result = "GAME_IN_PROGRESS";
				break;
			default:
				result = "INVALID";
			    break;
		}
		return result;
	}
}